#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	
	int n=0;
	
	cout << "\t INTEIRO PAR OU IMPAR \n";
	
	cout << "digite um inteiro: ";
	cin >> n;
	
	if (n % 2 <= 0) {
		
		cout << n << " par";
	}
	
	else {
		cout << n << " impar";
	}
	return 0;
}