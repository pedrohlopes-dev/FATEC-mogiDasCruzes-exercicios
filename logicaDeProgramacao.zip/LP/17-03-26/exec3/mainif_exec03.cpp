#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	
	int v1=0, v2=0;
	
	cout << "\t ORDEM CRESCENTE/DECRECENTE DE INTEIROS \n";
	
	cout << "digite 1 inteiro: ";
	cin >> v1;
	
	cout << "digite 2 inteiro: ";
	cin >> v2;
	
	for (int i=v1, j=v2;(i>=0 || j>=0); i--, j--) {
		
		cout << "DECRECENTE eh o i -> " << i << " | eh o j -> " << j << "\n";
		
	}
	
	cout << "-------------------------------------------------------- \n";
	
	for (int i=0, j=0;(i<=v1 || j<=v2); i++, j++) {
		
		cout << "CRESCENTE eh o i -> " << i << " | eh o j -> " << j << "\n";
	}
	return 0;
}