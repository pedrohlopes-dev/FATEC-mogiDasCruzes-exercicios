#include <iostream>
#include <cmath>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	
	float a=0, b=0, c=0;
	
	cout << "\t Calculo equacao 2 grau \n";
	
	cout << "digite b inteiro: ";
	cin >> b;
	
	cout << "digite a inteiro: ";
	cin >> a;
	
	cout << "digite c inteiro: ";
	cin >> c;
	
	float delta = pow(b,2) - 4*a*c;
	
	float v1 = ((0-b) + sqrt(delta))/(2*a);
	float v2 = ((0-b) - sqrt(delta))/(2*a);
	
	if (delta <0) {
		cout << "nao existe raizes reais " << delta;
		cout << "\n \t NAO FOI POSSIVEL REALIZAR CALCULO";
		
	}
	
	else if (delta == 0) {
	
		cout << "existe uma raizes real " << delta;
		cout << "\n {" << v1 << "," << v2 << "}";
	}
	
	else {
	
		cout << "existem duas raizes reais " << delta;	
		cout << "\n {" << v1 << "," << v2 << "}";
	}
	
	return 0;
}
