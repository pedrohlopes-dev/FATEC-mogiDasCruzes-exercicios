#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	
	int n1=0, n2=0;
	
	cout << "\t MOSTRAR ORDEM INTEIROS \n";
	
	cout << "digite 1 valor: ";
	cin >> n1;
	
	cout << "digite 2 valor: ";
	cin >> n2;
	
	if (n1>n2) {
		
		cout << "valor " << n1 << " maior que " << n2 << "\n";
		cout << n1 << " " << n2 << " ordem decrecente \n";
		cout << n2 << " " << n1 << " ordem crescente";
	}
	
	else {
		
		cout << "valor " << n2 << " maior que " << n1 << "\n";
		cout << n2 << " " << n1 << " ordem decrecente \n";
		cout << n1 << " " << n2 << " ordem crescente";
	}
	return 0;
}