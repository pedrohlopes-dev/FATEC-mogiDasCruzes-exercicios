#include <iostream>
using namespace std;

int inserirFaltas(int turma[][5]);
int calculoMedia(int turma[][5]);

int i, y, acumulador;

int main() {

    int turma[2][5];

    inserirFaltas(turma);

    for (i=0; i<=1; i++) {

        for (y=0; y<=4; y++) {

            cout << "\n aluno " << i+1 << " | mes " << y+1 << " -> "<< turma[i][y] << " ";
        }

        cout << "\n";

    }

    i = y = acumulador = 0;
    calculoMedia(turma);

    return 0;
}

int inserirFaltas(int t[2][5]) {

    if (i <=1) {

        if (y <=4) {

            cout << "digite falta do " << i+1 << " aluno em seu " << y+1 << " mes: ";

            cin >> t[i][y];
            y++;

            return inserirFaltas(t);
        }

        i++;
        y = 0;

        return inserirFaltas(t);
    }

    return 0;
}

int calculoMedia(int t[2][5]) {

    if (i <=1) {
        if (y <=4) {

            acumulador = acumulador + t[i][y];
            y++;

            return calculoMedia(t);
        }

        cout << "\n media aluno " << i+1 << " -> " << acumulador/5 << " ";

        acumulador =0;
        i++;
        y = 0;

        return calculoMedia(t);
    }

    return 0;
}