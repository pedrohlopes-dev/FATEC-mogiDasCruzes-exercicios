#include <stdio.h>

int main() {

    float p1, t1, m;

    printf("\t --MENU-- \n");
    printf("1 coisa lá \n 2 Sair \n :");
    scanf("%f",&p1);

    if (p1 == 1) {

        printf("1 trimestre: ");
        scanf("%f %f",&p1, &t1);

        m = (p1 * 0.7) + (t1 * 0.3);

        printf("2 trimestre: ");
        scanf("%f %f",&p1, &t1);

        m = m + ((p1 * 0.6) + (t1 * 0.4)) / 2;

        if (m >= 6) {

            printf("aprovado");
        }

        else {

            printf("nota recuperacao: ");
            scanf("%f",&p1);

            m = (m+p1) / 2;

            if (m >= 6) {
                printf("aprovado");
            }

            else {
                printf("insuficiente");
            }
        }
    }
    
    else {

            return 0;
    }
}
