#include <iostream>
using namespace  std;

int consistirInteiro(int);
int fibonacci();

int numero, contador=0;

int antes=0, atual=1, prox=0;

int main() {

    numero = consistirInteiro(numero);

    cout << atual << " ";

    fibonacci();

    return 0;
}

int consistirInteiro(int n) {

    do {
        cout << "digite inteiro: ";
        cin >> n;

    } while (n <=0);

    return n;
}

int fibonacci() {

    if (contador==numero) {

        return 1;
    }
    else {
        contador++;

        prox = antes + atual;

        cout << prox << " ";

        antes = atual;
        atual = prox;

        return fibonacci();
    }
}