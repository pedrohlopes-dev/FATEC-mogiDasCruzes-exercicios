#include <iostream>
using namespace std;

int consistirInteiros(int);
int paresC(int);

int main(int argc, char** argv) {
	
	cout << "\t determinados pares \n";
	
	int p = consistirInteiros(p);
	
    p = paresC(p);
    
    cout << p;
	
	return 0;
}

int consistirInteiros(int n){
	
	do {
		cout << "digite inteiro: ";
		cin >> n;
		
	} while (n <=0);
	
	return n;
}

int paresC(int n) {
	
	if (n == 0) {
		
		return 0;
	}
	
	if (n %2 ==0){
		
		cout << n << " ";
		
		n = n-1;
		
		return paresC(n);
		
	}
	
	n = n-1;
	
	return paresC(n);
	
	
}