#include <iostream>
using namespace std;

int consistirInteiro(int);
int fatorialC(int);

int main(int argc, char** argv) {
	
	int fatorial=0;
	
	cout << "\t mostra fatorial de numero \n";
	
	fatorial = consistirInteiro(fatorial);
	
	cout << fatorialC(fatorial);
	return 0;
}

int consistirInteiro(int n) {
	
	do {
		cout << "digite inteiro: ";
		cin >> n;
		
	} while (n <= 0);
	
	return n;
}

int fatorialC(int n) {
	
	if (n ==0) {
		
		return 1;
	}
	
	else {
		
		return n*fatorialC(n-1);
	}
}