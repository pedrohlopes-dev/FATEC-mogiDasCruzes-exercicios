#include <iostream>
using namespace std;

int consistirInteiro(int);
int somatoriaInteiros(int);

int main() {

    cout << "\t somatoria de inteiros \n";

    int numero = consistirInteiro(numero);

    cout << "total: " << somatoriaInteiros(numero);

    return 0;
}

int consistirInteiro(int n) {

    do {
        cout << "digite inteiro: ";
        cin >> n;

    } while (n <= 0);

    return n;
}

int somatoriaInteiros(int n) {

    if (n == 0) {

        return 1-1;
    }
    else {

        cout << n << " ";
        return n+somatoriaInteiros(n-1);
    }
}
