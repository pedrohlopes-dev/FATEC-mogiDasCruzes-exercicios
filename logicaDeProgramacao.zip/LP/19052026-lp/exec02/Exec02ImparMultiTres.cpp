#include <iostream>
using namespace std;

int consistirInteiro(int);
int imparMultiTres(int);

 int acumulador=0;

int main(int argc, char** argv) {
	
	cout << "\t numeros impar multi de 3 \n";
	
	int numero = consistirInteiro(numero);
    numero = imparMultiTres(numero);
    
    cout << "\n \t total: " << acumulador;

	return 0;
}

int consistirInteiro(int n) {
	
	do {
		cout << "digite maior que 2: ";
		cin >> n;
		
	} while (n <= 2);
	
	return n;
}

int imparMultiTres(int n) {
	
	if (n ==0) {
		
		return acumulador;
	}
	
	if (n % 2!=0 && n % 3==0) {
		
		cout << n << " ";
		
		acumulador = n + acumulador;
		n = n-1;
		
		return imparMultiTres(n);
	}
	
	n = n-1;
	return imparMultiTres(n);
	
}
