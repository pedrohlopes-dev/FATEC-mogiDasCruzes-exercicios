#include <iostream>
using namespace std;

int consistirInteiro(int);
int creditos(int);

int main() {

    int saldoMedio = consistirInteiro(saldoMedio);

    creditos(saldoMedio);

    return 0;
}

int consistirInteiro(int sm) {

    do {
        cout << "digite inteiro: ";
        cin >> sm;

    } while (sm <=0);

    return sm;
}

int creditos(int saldoMedio) {

    int r=0;

    if (saldoMedio <=200) {

        cout << "saldo -> " << saldoMedio << "\n" << r << " %credito -> 0%";
    }

    else if (saldoMedio <=400 ) {

        r = saldoMedio * 0.2;

        cout << "saldo -> " << saldoMedio << "\n" << r << " %credito -> 20%";
    }

    else if (saldoMedio <=600 ) {

        r = saldoMedio * 0.3;

        cout << "saldo -> " << saldoMedio << "\n" << r << " %credito -> 30%";
    }

    else {

        r = saldoMedio * 0.4;

        cout << "saldo -> " << saldoMedio << "\n" << r << " %credito -> 40%";
    }

    return 0;
}
