#include <iostream>
using namespace std;

int consistirInteiro(int);
int emBinario(int);

int binario[20], contador=0;

int main() {

    int i=0;

    for (i = 0; i <= 19; i++) {

        binario[i] = 0;
    }

    cout << "\t mostra em binario \n";

    int numero = consistirInteiro(numero);

    numero = emBinario(numero);

    for (i = 19; i >= 0; i--) {

        cout << binario[i] << " ";
    }

    return 0;
}

int consistirInteiro(int n) {

    do {
        cout << "digite inteiro: ";
        cin >> n;

    } while (n <= 0);

    return n;

}

int emBinario(int n) {

    if (n <= 1) {

        binario[contador] = n;

        return 0;
    }

    else {

        binario[contador] = n % 2;
        n = n/2;
        contador++;

        return emBinario(n);
    }


}
