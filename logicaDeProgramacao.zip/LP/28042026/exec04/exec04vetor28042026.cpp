#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	
	int A[15];
	int decimal =0, decimalEspelho=0;
	int resto=0;
	int i=0;
	
	cout << "digite inteiro positivo: ";
	cin >> decimal;
	
	
	for ( i=0; i < 15; i ++) {
		
		
		decimalEspelho = decimal;
	
		if (decimal >= 2) {
		
			
			decimal = decimal / 2;
			resto = decimalEspelho % 2;
			
			A[i] = resto;
			
			
			cout << "decimal = " << decimal << "\n";
			cou
			cout << "resto = " << resto << "\n";
			
		}
		
		else if (decimal <= 1) {
		
		A[i] = decimal;
		}
	
	}
	
	for (int y=15; y > 0; y--) {
		
		cout << A[y] << " ";
	}
	
	
	return 0;
}