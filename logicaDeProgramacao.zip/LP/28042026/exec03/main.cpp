#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	
	int A[4];
	int i =0;
	
	for (i=0; i<5; i++){
		
			cout << "digite valor " <<i << ": ";
			cin >> A[i];
	}
	
	while (i >= 0) {
		
		cout << A[i] << " ";
		i--;
	}
	return 0;
}