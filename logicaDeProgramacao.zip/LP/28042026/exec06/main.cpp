#include <iostream>
using namespace std;

int main() {

    int a[5], b[5], i, acumulador=1;

    for ( i = 0; i < 5; i++) {
        a[i] = 0;
        b[i] = 0;

    }

    for ( i = 0; i < 5; i++) {

        cout << "digite " << i << " valor: ";
        cin >> a[i];

        acumulador = acumulador * (i+1);

    }

    cout << "fatorial de " << a[i] << " = " << acumulador;

    return 0;
}
