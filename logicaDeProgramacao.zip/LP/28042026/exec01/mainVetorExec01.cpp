#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	
	int elementos[19];
	int acumulador=0;
	
	cout << "\t Mostra somatoria de pares \n";
	
	for (int i = 10; i<21; i++) {
		
		elementos[i] = i;
		
		if (elementos[i] % 2 == 0) {
			
			acumulador = acumulador + i;
			
			cout << "valor atual: " << elementos[i] << "\n";
		}
	}
	
	cout << "total? " << acumulador;
	return 0;
}