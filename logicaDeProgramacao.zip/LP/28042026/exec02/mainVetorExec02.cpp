#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	
	int A[9];
	int B[9];
	
	for (int i=0; i <10; i ++) {
		
		cout << "\n inserir valor de " << i << ": ";
		cin >> A[i];
		B[i] = A[i]*2;
		
		cout << "\n \t A -> " << A[i] << " B -> " << B[i] << "\n";
		 	
	}
	return 0;
}