#include <stdio.h>

int main() {

    int menu, menuP;

    float prova1, trabalho1, prova2, trabalho2, desconto;

    printf("\n \t ==MENU== \n");



    printf("\n insira valor menu: ");
    scanf("%d", &menu);

     do {

        switch (menu) {

            default:
                printf("VALOR INVALIDO \n");
                break;

            case 1:

                printf("MEDIA 1 \n");

                printf("=== MEDIA FATEC ===");

                printf("\nDigite o valor da prova do 1 Bimestre: ");
                scanf("%f", &prova1);
                printf("\nDigite o valor do trabalho do 1 Bimestre: ");
                scanf("%f", &trabalho1);
                printf("\nDigite o valor da prova do 2 Bimestre: ");
                scanf("%f", &prova2);
                printf("\nDigite o valor do trabalho do 2 Bimestre: ");
                scanf("%f", &trabalho2);

                prova1 = prova1 * 0.7;
                trabalho1 = trabalho1 * 0.3;
                prova1 += trabalho1; // prova1 agora é a soma da nota do 1 bimestre

                prova2 = prova2 * 0.6;
                trabalho2 = trabalho2 * 0.4;
                prova2 += trabalho2; //prova2 agora é a soma da nota do 2 bimestre

                prova2 = (prova2 + prova1)/2; //prova2 agora é a média

                if (prova2 >= 6)
                {
                    printf("APROVADO!!");
                }
                if(prova2 < 6)
                {
                    printf("FICOU DE RECUPERACAO!!");
                    printf("\nDigite a nota da prova de recuperacao: ");
                    scanf("%f", &prova1); //prova1 agora é a prova de recuperação
                    trabalho2 = (prova2 + prova1)/2; //trabalho1 agora é a media final

                    if (trabalho1 >= 6)
                    {
                        printf("AGORA SIM APROVADO!! :)");
                    }
                    if(trabalho1 < 6)
                    {
                        printf("REPROVADO DE VEZ :(");
                    }

                }

                break;

            case 2:
                printf("MEDIA 2 \n");

                printf("=== MEDIA FATEC ===");

                printf("\nDigite o valor da prova do 1 Bimestre: ");
                scanf("%f", &prova1);
                printf("\nDigite o valor do trabalho do 1 Bimestre: ");
                scanf("%f", &trabalho1);
                printf("\nDigite o valor da prova do 2 Bimestre: ");
                scanf("%f", &prova2);
                printf("\nDigite o valor do trabalho do 2 Bimestre: ");
                scanf("%f", &trabalho2);

                prova1 = prova1 * 0.7;
                trabalho1 = trabalho1 * 0.3;
                prova1 += trabalho1; // prova1 agora é a soma da nota do 1 bimestre

                prova2 = prova2 * 0.6;
                trabalho2 = trabalho2 * 0.4;
                prova2 += trabalho2; //prova2 agora é a soma da nota do 2 bimestre

                prova2 = (prova2 + prova1)/2; //prova2 agora é a média

                if (prova2 >= 6)
                {
                    printf("APROVADO!!");
                }
                else
                {
                    printf("FICOU DE RECUPERACAO!!");
                    printf("\nDigite a nota da prova de recuperacao: ");
                    scanf("%f", &prova1); //prova1 agora é a prova de recuperação
                    trabalho2 = (prova2 + prova1)/2; //trabalho1 agora é a media final

                    if (trabalho1 >= 6)
                    {
                        printf("AGORA SIM APROVADO!! :)");
                    }
                    else
                    {
                        printf("REPROVADO DE VEZ :(");
                    }
                }

                break;

            case 3:
                printf("DESCONTO \n");

                printf("\nDigite o valor para aplicar um desconto nele ");
                scanf("%f", &desconto);
                printf("\nDigite qual desconto que voce deseja que seja aplicado nele ");
                printf("\n1. 10%%\n2. 25%%\n3. 35%%\n4. 45%%\n");
                scanf("%i", &menuP);

                switch(menuP){
                    default: printf("Opcao nao encontrada");
                        break;
                    case 1: desconto*=0.10;
                        printf("Preco descontado:, %f", desconto);
                        break;
                    case 2: desconto*=0.25;
                        printf("Preco descontado:, %f", desconto);
                        break;
                    case 3: desconto*=0.35;
                        printf("Preco descontado:, %f", desconto);
                        break;
                    case 4: desconto*=0.45;
                        printf("Preco descontado:, %f", desconto);

                }
                break;

            case 4:
                printf("FATORIAL \n");

                printf("\nColoque um numero para calcular a fatorial dele:");
                scanf("%f", &prova1);
                trabalho1=prova1;
                do{
                    prova2= trabalho1-1;
                    prova1= prova1 *prova2;
                    trabalho1=trabalho1-1;
                }while(trabalho1!=1);
                printf("O seu fatorial deu:%f", prova1);

                break;

            case 5:
                printf("FIBONACCI \n");

                printf("\n Coloque qual termo voce quer ver: ");
                scanf("%f", &trabalho2);

                prova1 = 1;
                trabalho1 = 0;
                prova2 = 0;
                desconto = 0;
                do{
                    trabalho1 = trabalho1 + prova1;
                    prova1 = prova2;
                    prova2 = trabalho1;

                    printf("%.0f ", prova2);

                    desconto++;

                }while(desconto < trabalho2);

                break;

            case 6:
                printf("P.A \n");



                break;

            case 7:
                printf("FATORIAL [WHILE] \n");
                break;

            case 8:
                printf("FIBONACCI [WHILE] \n");

                printf("\n Coloque qual termo voce quer ver: ");
                scanf("%f", &trabalho2);

                prova1 = 1;
                trabalho1 = 0;
                prova2 = 0;
                desconto = 0;
                while (desconto < trabalho2){
                    trabalho1 = trabalho1 + prova1;
                    prova1 = prova2;
                    prova2 = trabalho1;

                    printf("%.0f ", prova2);

                    desconto++;

                }

                break;

            case 9:
                printf("P.A [WHILE] \n");


                break;

            case 10:
                printf("FATORIAL [FOR] \n");

                printf("\nColoque um numero para calcular a fatorial dele: ");
                scanf("%f", &prova1);

                for(trabalho1 = prova1; trabalho1!=1; trabalho1--){

                    prova2= trabalho1-1;
                    prova1= prova1 *prova2;

                }
                printf("\nO seu fatorial deu:%f \n", prova1);

                break;

            case 11:
                printf("FIBONACCI [FOR] \n");
                break;

            case 12:
                printf("P.A [FOR] \n");
                break;

            case 13:
                printf("MAIOR VALOR DE DIGITOS \n");

                printf("\n\t diz maior valor de 3 digitados \n");

                printf("digite valores: ");
                scanf("%f %f %f", &prova1, &prova2, &trabalho1);

                if( prova1 > prova2 && prova1 > trabalho1) {

                    printf("%f maior valor", prova1);
                }

                else if(prova2 > prova1 && prova2 > trabalho1) {

                    printf("%f maior valor", prova2);
                }

                else {

                    printf("%f maior valor", trabalho1);

                }

                break;

            case 14:
                printf("MENOR VALOR DE DIGITOS \n");

                printf("\n\t diz menor valor de 3 digitados \n");

                printf("digite valores: ");
                scanf("%f %f %f", &prova1, &prova2, &trabalho1);

                if( prova1 < prova2 && prova1 < trabalho1) {

                    printf("%f menor valor", prova1);
                }

                else if(prova2 < prova1 && prova2 < trabalho1) {

                    printf("%f menor valor", prova2);
                }

                else {

                    printf("%f menor valor", trabalho1);

                }

                break;

            case 15: // CORRIGIR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                printf("VALORES INVERSAMENTE \n");

                printf("Escreva dez valores e veja eles inversamente:");

                int vetor[10];

                for(int valor = 0; valor<9; valor++) {
                    printf("digite os dez valores:");
                    scanf("%i", &vetor[valor]);
                    printf("\n");
                    for(int valor = 9; valor>0; valor--){
                        printf("%i", vetor[valor]);
                    }
                }

                break;

            case 16:
                printf("SEI NÃO FI \n");
                break;

            case 17:
                printf("SAIU \n");
                break;

        }

        printf("\n insira valor menu: ");
        scanf("%d", &menu);

    }while (menu != 17);

    return 0;
}
