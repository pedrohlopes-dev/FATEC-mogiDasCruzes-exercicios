#include <iostream>
using namespace  std;

int main() {
    int alunos[2][5], mediaAlunos[2], acumulador=0, i,j;

    for (i=0;i<2;i++) {
        for (j=0;j<5;j++) {

            alunos[i][j] = 0;
        }

        mediaAlunos[i] = 0;
    }

    for (i=0;i<2;i++) {
        for (j=0;j<5;j++) {

            cout << "\t ---------------<aluno" << i+1 <<">--------------- \n";

            cout << "digite faltas do " << i+1 << " aluno no " << j+1 << " mes: ";
            cin >> alunos[i][j];

            acumulador = acumulador + alunos[i][j];

        }

        mediaAlunos[i] = acumulador/5;
        acumulador = 0;
    }

    for (i=0;i<2;i++) {
            cout << "\n media aluno " << i+1 << " : " << mediaAlunos[i] << " ";
    }

    return 0;
}