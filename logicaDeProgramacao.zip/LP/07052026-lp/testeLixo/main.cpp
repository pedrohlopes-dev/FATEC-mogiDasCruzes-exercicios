#include <iostream>
using namespace std;

void teste() {
    int x = 123;
}

int main() {
    teste();

    int y;

    cout << y;
}