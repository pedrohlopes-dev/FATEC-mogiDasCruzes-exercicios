#include <iostream>
using namespace std;

int main() {

    int a[3][3] = {
        {12, 1, 4},
        {5, 6, 67},
        {23, 11, 98}
    },

     b[3][3] = {
        {2, 12, 63},
        {32, 78, 10},
        {66, 77, 44}
    },

    c[3][3];

    cout << "\t soma matrizes \n";

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {

            c[i][j] = a[i][j] + b[i][j];
            cout << c[i][j] << " ";
        }
        cout << "\n";
    }

    return 0;
}