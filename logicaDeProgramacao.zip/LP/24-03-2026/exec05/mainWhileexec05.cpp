#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	
	float alunos=0, notas=0, acumulador=0, acumuladorN=2, acumuladorturma=0, notaP=0, totalverificado=0;
	
	cout << "caculo media 50 \n";
	
	while (alunos < 2) {
		
		while (notas < 3) {
			
			cout << "\n digite a " << notas+1 << " nota do " << alunos+1 << " aluno: \n";
			cin >> notaP;
			
			notaP = notaP * acumuladorN;
			
			acumuladorN = acumuladorN + 1;
			
			acumulador = notaP + acumulador;
			
			notas++;
		}
		
		totalverificado = acumulador/9;
		cout << "media aluno " << alunos+1 << " media ponderada: " << totalverificado << " ";
		
		if (totalverificado > 6) {
			
			cout << "aprovado \n";
		}
		
		else {
			cout << "reprovado \n";
		}
		
		acumuladorturma = totalverificado + acumuladorturma;
		
		acumuladorN = 2;
		notas=notaP=acumulador=totalverificado=0;
		
		alunos++;
		
		
	} 
	
	cout << "media da turma: " << acumuladorturma/alunos;
	return 0;
}