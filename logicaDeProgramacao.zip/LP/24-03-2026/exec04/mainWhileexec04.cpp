#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	
	int i=0, v=0, d=0, f=0;
	
	cout << "ler 10 dentro/fora \n";
	
	while (i < 11) {
		
		cout << "digite um valor: ";
		cin >> v;
		
		if (v < 21 && v > 9){
			
			cout << "dentro " << v << "\n";
			d++;
		}
		
		else {
			cout << "fora " << f << "\n";
			f++;
		}
		
		i++;
		
		
	}
	
	cout << "total dentro: " << d << " total fora: " << f;

	return 0;
}