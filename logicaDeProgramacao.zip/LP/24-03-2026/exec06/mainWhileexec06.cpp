
#include <iostream>
using namespace std;

int main(int argc, char** argv) {
	
	int gerador=1000, v=0;
	
	cout << "dao resto igual a 5 de 1999 \n";
	
	while (gerador < 1999) {
		
		v = gerador % 11;
		
		if (v == 5) {
		    
		    cout << "tem resto 5 -> " << gerador << "\n";
		}
		
		gerador++;
	}
	return 0;
}
