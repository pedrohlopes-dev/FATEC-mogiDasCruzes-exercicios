#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	
	int decimal=0, resto=0;
	
	
	do {
		cout << "digite decimal positivo: ";
		cin >> decimal;
	} while (decimal < 0);
	
	while (true) {
		if (decimal != 1) {
			
			resto = decimal % 2;
			decimal = decimal /2;	
			cout << resto;		
		}
		
		else {
			
			cout << decimal;
			break;
		}
		
		
	}
	return 0;
}