#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	
	int n=1;
	
	do {
		if (n % 2 ==1) {
			
			cout << n << " ";
		}
		
		n++;
	} while (n < 80);
	
	cout << "fim_repete \n";
	n=1;
	
	while (n < 80) {
		
		if (n % 2 ==1) {
			
			cout << n << " ";
		}
		
		n++;
		
	}
	
	cout << "fim_enquanto \n";
		
	for (n=1; n<80; n++) {
		
		if (n % 2 ==1) {
			
			cout << n << " ";
		}
		
		n++;
		
	}
	
	cout << "fim_para \n";
	return 0;
}