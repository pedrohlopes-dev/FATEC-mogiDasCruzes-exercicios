#include <iostream>
using namespace std;

int main() {

    int numero, soma=0;

    cout << "digite numero: ";
    cin >> numero;

    for (int i=1; i < numero; i++) {

        if (numero % i ==0) {

            soma = soma + i;
        }
    }

    if (soma == numero)
        cout << "numero eh perfeito";


    else
        cout << "numero nao eh perfeito";


    return 0;
}

int binarioFunct() {

    int binario[20], numero;

    cout << "\t torna binario \n";

    cout << "digite inteiro: ";
    cin >> numero;

    for (int i =19; i >= 0; i--) {
        binario[i] = 0;
    }

    for (int i =0; i < 19; i++) {

        if (numero <=1) {

            binario[i] = numero;

            break;
        }

        else {

            binario[i] = numero %2;
            numero = numero / 2;

        }
    }

    for (int i =19; i >= 0; i--) {
        cout << binario[i] << " ";
    }

    return 0;
}
