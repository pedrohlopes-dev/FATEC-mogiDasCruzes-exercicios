#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int consistirInteiros(int);
int somatoriaInteiros(int, int);

int main(int argc, char** argv) {
	
	cout << "\t soma de inteiros \n";
	
	int n1=consistirInteiros(n1), 
		n2=consistirInteiros(n2);
		
		cout << n1 << "+" << n2 << " = " << somatoriaInteiros(n1, n2);
	
	return 0;
}

int consistirInteiros(int n){
	
	do {
		cout << "digite valor: ";
		cin >> n;
	} while(n <=0 );
	
	return n;
}

int somatoriaInteiros(int n, int j) {
	
	n = n+j;
	
	return n;
}