#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int consistirInteiro(int);
int verificarPar(int);

int main(int argc, char** argv) {
	
	cout << "\t verifica par/impar \n";
	
	int n1 = consistirInteiro(n1);
	
	string r;
	
	cout << "o numero eh " << verificarPar(n1);
	
	return 0;
}

int consistirInteiro(int n){
	
	do {
		cout <<"digite: ";
		cin >> n;
		
	}while (n <=0);
	
	return n;
}

int verificarPar(int n){
	
	if (n % 2 ==0) {
		
		cout << "par";
	}
	
	else {
		
		cout << "impar";
	}
}