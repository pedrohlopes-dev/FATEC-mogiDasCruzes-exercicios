#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int consistirInteiros(int);
int somatoriaInteiros(int);

int main(int argc, char** argv) {
	
	cout << "\t somatoria de inteiros \n";
	
	int n1 = consistirInteiros(n1);
	
	cout << "a somatoria de " << n1 << " eh " << somatoriaInteiros(n1); 
	
	return 0;
}

int consistirInteiros(int n){
	
	do {
		cout << "digite inteiro: ";
		cin >> n;
		
	} while (n <=0);
	
	return n;
}

int somatoriaInteiros(int n) {
	
	int acumulador=0;
	
	for (int i=0; i<=n; i++) {
		
		acumulador = acumulador + i;
	}
	
	return n = acumulador;
}