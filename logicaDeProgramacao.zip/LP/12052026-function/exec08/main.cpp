#include <iostream>
using namespace std;

int insercaoInteiros(int);
int crescenteDecrescente(int, int);

int main() {

    cout << "\t coloca em ordem crescente decrescente \n";

    int n1 = insercaoInteiros(n1),
        n2 = insercaoInteiros(n2);

    cout << "a ordem eh: \n" << crescenteDecrescente(n1,n2);

    return 0;
}

int insercaoInteiros(int n) {

    cout << "digite inteiro: ";
    cin >> n;

    return n;
}

int crescenteDecrescente(int n, int j) {

    if (n > j) {

        cout << n << " " << j << " <- decrescente \n";
        cout << j << " " << n << " <- crescente \n";
    }

    else if (n < j) {

        cout << j << " " << n << " <- decrescente \n";
        cout << n << " " << j << " <- crescente \n";
    }

    else {
        cout << j << " " << n << " <- iguais \n";
    }

}

