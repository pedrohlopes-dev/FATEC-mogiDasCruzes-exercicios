#include <iostream>
using namespace std;

int consistirInteiros(int);
int indentificaTriangulo(int, int, int);

int main() {

    cout << "\t indentifica triangulos \n";

    int x = consistirInteiros(x),
        y = consistirInteiros(y),
        z = consistirInteiros(z);

    cout << "o triangulo eh: " << indentificaTriangulo(x, y, z);

    return 0;
}

int consistirInteiros(int n) {

    do {
        cout << "digite: ";
        cin >> n;

    } while (n <= 0);

    return n;
}

int indentificaTriangulo(int x, int y, int z) {

    if ((x == y && x==z) && (z==y) ) {

        cout << "equilatero";
    }
    
    else if ((x != y && x!=z) && (z!=y)) {

            cout << "escaleno";
    }

    else {
        cout << "isoceles";
    }

    return 0;
}