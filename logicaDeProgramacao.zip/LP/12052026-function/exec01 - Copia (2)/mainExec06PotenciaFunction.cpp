#include <iostream>
#include <cmath>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int consistirInteiro(int);
int calculoPotencia(int, int);

int main(int argc, char** argv) {
	
	cout << "\t calculo potencia \n";
	
	int n1 = consistirInteiro(n1),
		n2 = consistirInteiro(n2);
		
	cout << "a potencia do primeiro valor informado eh: " << calculoPotencia(n1, n2);
	return 0;
}

int consistirInteiro(int n){
	
	do {
		cout << "digite inteiro: ";
		cin >> n;
		
	} while(n <0);
	
	return n;
}

int calculoPotencia(int n, int j){
	
	n = pow(n, j);
	
	return n;
}